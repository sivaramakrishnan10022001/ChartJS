import React from "react";
import Chart from "../../SourceFiles/chart";
class PolarAreaChart extends React.Component {
  constructor() {
    super();
    this.state = {

    }
  }
 //=======================================================================
  componentDidMount() {
    const ctx = document.getElementById('myChart').getContext('2d');
    new Chart(ctx, {
        type: 'polarArea',
        data: this.props.data,
        options: this.props.options,
    });
  }
//=======================================================================
  render() {
    return (
      <div style={{ width: "500px", height: "400px" }}>
        <h1>Polar Area Chart</h1>
        <canvas id="myChart"  ></canvas>
      </div>
    )
  }

}

export default PolarAreaChart;
