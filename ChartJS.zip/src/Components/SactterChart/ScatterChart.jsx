import React from "react";
import Chart from "../../SourceFiles/chart";
class ScatterChart extends React.Component {
  constructor() {
    super();
    this.state = {

    }
  }
 //=======================================================================
  componentDidMount() {
    const chartAreaBorder = {
      id: 'chartAreaBorder',
      beforeDraw(chart, args, options) {
        const {ctx, chartArea: {left, top, width, height}} = chart;
        ctx.save();
        ctx.strokeStyle = options.borderColor;
        ctx.lineWidth = options.borderWidth;
        ctx.setLineDash(options.borderDash || []);
        ctx.lineDashOffset = options.borderDashOffset;
        ctx.strokeRect(left, top, width, height);
        ctx.restore();
      }
    };
    const ctx = document.getElementById('myChart').getContext('2d');
    new Chart(ctx, {
        type: 'scatter',
        data: this.props.data,
        options: this.props.options,
        plugins: [chartAreaBorder]
    });
  }
//=======================================================================
  render() {
    return (
      <div style={{ width: "800px", height: "800px" }}>
        <h1>Scatter Chart</h1>
        <canvas id="myChart"  ></canvas>
      </div>
    )
  }

}

export default ScatterChart;
