import React from "react";
import Chart from "../../SourceFiles/chart";
class SteppedLineChart extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    componentDidMount() {
        const ctx = document.getElementById('myChart').getContext('2d');
        const initProgress = document.getElementById('initialProgress');
        const progress = document.getElementById('animationProgress');
        new Chart(ctx, {
            type: 'line',
            data: this.props.data,
            options: this.props.options,
        });

    }

    render() {
        return (
            <div style={{ width: "800px", height: "800px" }}>
                <div id="initialProgress"></div>
                <div id="animationProgress"></div>
                <h1>Stepped Line Chart</h1>
                <canvas id="myChart"  ></canvas>
            </div>
        )
    }

}
export default SteppedLineChart;