import React from "react";
import Chart from "../../SourceFiles/chart";
class BarLineChart extends React.Component {
  constructor() {
    super();
    this.state = {

    }
  }
 //=======================================================================
  componentDidMount() {
    const ctx = document.getElementById('myChart').getContext('2d');
    const plugin = {
      id: 'custom_canvas_background_color',
      beforeDraw: (chart) => {
        const ctx = chart.canvas.getContext('2d');
        ctx.save();
        ctx.globalCompositeOperation = 'destination-over';
        ctx.fillStyle = 'rgb(241, 241, 241,0.7)';
        ctx.fillRect(0, 0, chart.width, chart.height);
        ctx.restore();
      
       

      }
    }
    new Chart(ctx, {
        type: 'bar',
        data:this.props.data,
        options: this.props.options,
        plugins: [plugin],
    });
  }
//=======================================================================
  render() {
    return (
      <div style={{ width: "800px", height: "800px" }}>
        <h1>BarLine Chart</h1>
        <canvas id="myChart"  ></canvas>
      </div>
    )
  }

}

export default BarLineChart;





