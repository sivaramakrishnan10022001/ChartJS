import React from "react";
import Chart from "../../SourceFiles/chart";
class RadarChart extends React.Component {
  constructor() {
    super();
    this.state = {

    }
  }
 //=======================================================================
  componentDidMount() {
    const ctx = document.getElementById('myChart').getContext('2d');
    new Chart(ctx, {
        type: 'radar',
        data: this.props.data,
        options: this.props.options,
    });
  }
//=======================================================================
  render() {
    return (
      <div style={{ width: "500px", height: "400px" }}>
        <h1>Radar Chart</h1>
        <canvas id="myChart"  ></canvas>
      </div>
    )
  }

}

export default RadarChart;
