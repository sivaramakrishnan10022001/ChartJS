import React from "react";
import Chart from "../../SourceFiles/chart";
class MultiLineChart extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    componentDidMount() {
        const ctx = document.getElementById('myChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: this.props.data,
            options: this.props.options,
        });

    }

    render() {
        return (
            <div style={{ width: "700px", height: "800px" }}>
                <h1>Multi Line + interpolation Chart</h1>
                <canvas id="myChart"  ></canvas>
            </div>
        )
    }

}

export default MultiLineChart;

