import React from "react";
import Chart from "../../SourceFiles/chart";
class AreaChart extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    componentDidMount() {
        const ctx = document.getElementById('myChart').getContext('2d');
        const plugin = {
            id: 'custom_canvas_background_color',
            beforeDraw: (chart) => {
              const ctx = chart.canvas.getContext('2d');
              ctx.save();
              ctx.globalCompositeOperation = 'destination-over';
              ctx.fillStyle = '#E0FFFF';
              ctx.fillRect(0, 0, chart.width, chart.height);
              ctx.restore();
            }
          }
        new Chart(ctx, {
            type: 'line',
            data: this.props.data,
            options: this.props.options,
           
        });

    }

    render() {
        return (
            <div style={{ width: "500px", height: "400px" }}>
                <h1>Area Chart</h1>
                <canvas id="myChart" ></canvas>
            </div>
        )
    }

}

export default AreaChart;