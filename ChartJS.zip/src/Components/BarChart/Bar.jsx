import React from "react";
import Chart from "../../SourceFiles/chart";
class BarChart extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    componentDidMount() {
        const ctx = document.getElementById('myChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: this.props.data,
            options: this.props.options,
        });

    }

    render() {
        return (
            <div style={{ width: "800px", height: "800px" }}>
                <h1>Bar Chart</h1>
                <canvas id="myChart"  ></canvas>
            </div>
        )
    }

}

export default BarChart;





