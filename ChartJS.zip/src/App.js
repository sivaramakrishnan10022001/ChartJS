import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Barchart from './Components/BarChart/Bar';
import AreaChart from './Components/AreaChart/AreaChart';
import BubbleChart from './Components/BubbleChart/BubbleChart';
import BarLineChart from './Components/ComboBarLineChart/ComboBarLineChart';
import StackedBarChart from './Components/StackedBar/StackedBar';
import DoughnutChart from './Components/DoughnutChart/DoughnutChart';
import PieChart from './Components/PieChart/PieChart';
import MultiSeriesPieChart from './Components/MultiSeriesPie/MultiSeriesPieChart';
import QScatterChart from './Components/QScatter/QScatter';
import PolarAreaChart from './Components/PolarChart/PolarAreaChart';
import RadarChart from './Components/RadarChart/RadarChart';
import LineChart from './Components/LineChart/LineChart';
import ScatterChart from './Components/SactterChart/ScatterChart';
import MultiLineChart from './Components/MultiLine/MultiLine';
import SteppedLineChart from './Components/SteppedLine/SteppedLine';
import './App.css';

function App() {
  var areaData = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August'],
    datasets: [
      {
        label: 'D0',
        data: [73.15, 77.54, 53.72, 55.76, 62.16, 62.62, 64.47, 79.6],
        borderColor: '#504A4B',
        backgroundColor: '#B6B6B4',
        hidden: true
      },
      {
        label: 'D1',
        data: [30.96, 59.3, 29.79, 38.75, 60.23, 52.77, 45.98, 72.6],
        borderColor: '#191970',
        backgroundColor: '#728FCE',
        fill: '-1' //Target (visibility)
      },
      {
        label: 'D2',
        data: [43.62, 49.31, 34.79, 72.75, 29.23, 33.17, 41.38, 67.6],
        borderColor: '#2554C7',
        backgroundColor: '#3BB9FF',
        hidden: true,
        fill: 1
      },
      {
        label: 'D3',
        data: [20.12, 32.19, 49.29, 92.15, 79.13, 53.77, 48.18, 72.932],
        borderColor: '#0AFFFF',
        backgroundColor: '#CCFFFF',
        fill: '-1'
      },
      {
        label: 'D4',
        data: [50.13, 39.11, 29.89, 41.75, 27.13, 93.12, 83.17, 28.932],
        borderColor: '#008080',
        backgroundColor: '#93FFE8',
        fill: '-1'
      },
      {
        label: 'D5',
        data: [30.53, 59.71, 83.439, 38.43, 92.32, 29.245, 43.17, 94.932],
        borderColor: '#254117',
        backgroundColor: '#50C878',
        fill: { above: '#5FAD07', below: '#0779AD', target: { value: 350 } }
      }
    ]
  };
  var areaOptions = {
    animations: {
      tension: {
        duration: 2000,
        easing: 'easeOutBounce',
        delay: 5000, //Delay before starting the animations.
        from: 1,
        to: 0,
        loop: false,
      }
    },
    scales: {
      x: {
        display: true,        // show/ hide x-axis(default : true)
        grid: {
          display: false,      // show/hide grid line in x-axis(default : true)
        },
      },
      y: {
        stacked: true,
        display: true,      // same as x-axis
        grid: {
          display: false
        }
      }
    },
    responsive: true, // Instruct chart js to respond nicely.
    maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height 
  };
  var barData = {
    labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    datasets: [{
      label: '# of Votes',
      data: [12, 19, 3, 5, 2, 3],
      borderSkipped: ['right', 'left', 'top'],
      barThickness: 20,
      borderWidth: 25,
      backgroundColor: [ // change bar colors
        'rgba(255, 22, 72)',
        'rgba(0, 0, 255)',
        'rgba(255, 255, 0)',
        'rgba(0, 128, 0)',
        'rgba(	106, 13, 173)',
        'rgba(255, 165, 0)'
      ],
      hoverBackgroundColor: [
        'rgba(255, 185, 212)',
        'rgba(204, 238, 255)',
        'rgba(255, 255, 195)',
        'rgba(187, 255, 187)',
        'rgba(255, 214, 255)',
        'rgba(255, 223, 174)',
      ],
      hoverBorderRadius: 64,
      borderColor: 'rgba(0, 0, 0)',
      borderWidth: 1
    }]
  };
  var barOptions = {
    indexAxis: 'y',
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Chart.js Floating Bar Chart'
      }
    },
    devicePixelRatio: 3, //  to a value other than 1 will force the canvas size to be scaled by that amount, relative to the container size.
    scales: {
      x: {
        display: true,        // show/ hide x-axis(default : true)
        grid: {
          display: false,      // show/hide grid line in x-axis(default : true)
        },
      },
      y: {
        display: true,      // same as x-axis
        grid: {
          display: false
        }
      }
    },
    elements: {
      bar: {
        backgroundColor: 'rgb(255, 255, 223)',
      },
    },
  };
  var sBarData = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [
      {
        label: 'Dataset 1',
        data: [44.839, -43.318, -92.147, 78.517, -2.85, 29.518],
        backgroundColor: '#92DC38',
        stack: 'Stack 0',
      },
      {
        label: 'Dataset 2',
        data: [-53.122, 15.305, 73.651, 72.531, -67.166, -31.36, 40.77],
        backgroundColor: '#DCCA38',
        stack: 'Stack 0',
      },
      {
        label: 'Dataset 3',
        data: [48.711, -49.733, -81.718, 29.302, 85.796, -28.216, -58, 482],
        backgroundColor: '#38C7DC',
        stack: 'Stack 1',
      },
    ]
  };
  var sBarOptions = {
    plugins: {
      title: {
        display: true,
        text: 'Chart.js Bar Chart - Stacked'
      },
    },
    responsive: true,
    scales: {
      x: {
        stacked: true,
        grid: {
          display: false,
        }
      },
      y: {
        stacked: true,
      }
    }
  }
  var lineData = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [
      {
        label: 'Dataset 1',
        data: [-76.4, 62.84, -91.57, 40.23, -13.67, -86.92, 44.29],
        borderColor: '#FF00FF',
        backgroundColor: '#FA8072',
        yAxisID: 'y',
      },
      {
        label: 'Dataset 2',
        data: [19.82, -17.26, 2.03, 28.69, -16.45, -19.879, 80.267],
        borderColor: '#0AFFFF',
        backgroundColor: 'rgb(204, 255, 255,0.4)',
        yAxisID: 'y1',
        fill: true,
      },
      {
        label: 'Dataset 3',
        data: [59.82, -1.26, -62.03, 21.69, -56.25, 19.879, -30.267],
        borderColor: '#7D0552',
        backgroundColor: '#E8ADAA',
        yAxisID: 'y2',
        borderDash: [5, 5],
        pointStyle: ['circle', 'rect']
      }
    ],
  };
  var lineOptions = {
    legend: { display: true },
    elements: {
      point: {
        radius: 5,  // poin size default 3
        pointStyle: 'triangle', //default style is circle. values:('cross','crossRot','dash','line','rect','rectRounded','rectRot','star','triangle')
        rotation: 90, //Point rotation (in degrees).
        hitRadius: 3, //Extra radius added to point radius for hit detection. default -1
        borderColor: '#008080',
        color: '#008080',
      },
      line: {
        tension: 5,
        backgroundColor: '#008080',
        borderWidth: 2,//Line stroke width. default 3
        cubicInterpolationMode: 'default',//default produces pleasant curves for all types of datasets 'monotone' algorithm is more suited to y = f(x) datasets: it preserves monotonicity (or piecewise monotonicity) of the dataset being interpolated,
      },
    },
    layout: {
      padding: 20
    },
    plugins: {
      legend: {
        labels: {
          // This more specific font property overrides the global property
          font: {
            size: 16, // font size
            style: 'italic',
            lineHeight: 20,
          }
        }
      }
    },
    animations: {
      tension: {
        duration: 5000, // number of milliseconds
        easing: 'linear',
        from: 1, //Start value for the animation.
        to: 0,
        loop: true
      },
      y: {
        easing: 'easeInOutElastic',
        from: (ctx) => {
          if (ctx.type === 'data') {
            if (ctx.mode === 'default' && !ctx.dropped) {
              ctx.dropped = true;
              return 0;
            }
          }
        }
      }
    },
    scales: {
      x: {
        display: true,        // show/ hide x-axis(default : true)
        grid: {
          display: false,      // show/hide grid line in x-axis(default : true)
        },
      },
      y1: {
        grid: {
          display: false
        }
      },
      y2: {
        display: false,
        grid: {
          display: false
        }
      },
      y: {
        display: false,      // same as x-axis
        grid: {
          display: false
        }
      }
    }
  };
  var sLineData = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [
      {
        label: 'Dataset 1',
        data: [-76.4, 62.84, -91.57, 40.23, -13.67, -86.92, 44.29],
        borderColor: '#FF00FF',
        backgroundColor: '#FA8072',
        yAxisID: 'y',
      },
      {
        label: 'Dataset 2',
        data: [19.82, -17.26, 2.03, 28.69, -16.45, -19.879, 80.267],
        borderColor: '#0AFFFF',
        backgroundColor: '#CCFFFF',
        yAxisID: 'y1',
        fill: true,
        stepped: true,
      },
      {
        label: 'Dataset 3',
        data: [59.82, -1.26, -62.03, 21.69, -56.25, 19.879, -30.267],
        borderColor: '#7D0552',
        backgroundColor: '#E8ADAA',
        yAxisID: 'y2',
        borderDash: [5, 5],
        stepped: true,
      }
    ]
  };
  var sLineOptions = {
    responsive: true,
    interaction: {
      intersect: false,
      axis: 'x'
    },
    scales: {
      x: {
        display: true,        // show/ hide x-axis(default : true)
        grid: {
          display: false,      // show/hide grid line in x-axis(default : true)
        },
      },
      y1: {
        grid: {
          display: false
        }
      },
      y2: {
        display: false,
        grid: {
          display: false
        }
      },
      y: {
        display: false,      // same as x-axis
        grid: {
          display: false
        }
      }
    }
  };
  var mLineData = {
    labels: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11'],
    datasets: [
      {
        label: 'Cubic interpolation (monotone)',
        data: [0, 20, 20, 60, 60, 120, NaN, 180, 120, 125, 105, 110, 170],
        borderColor: '#FF0000',
        fill: false,
        cubicInterpolationMode: 'monotone',
        tension: 0.4,
        spanGaps: false,
      }, {
        label: 'Cubic interpolation',
        data: [0, 20, 20, 60, 60, 120, NaN, 180, 120, 125, 105, 110, 170],
        borderColor: '#0000FF',
        fill: false,
        tension: 0.4
      }, {
        label: 'Linear interpolation (default)',
        data: [0, 20, 20, 70, 60, 150, NaN, 180, 120, 145, 125, 50, 170],
        borderColor: '#008000',
        fill: false
      }
    ]
  }
  var mLineOptions = {
    animations: {
      tension: {
        duration: 5000, // number of milliseconds
        easing: 'linear',
        from: 3, //Start value for the animation.
        to: 0,
        loop: true
      }
    },
    interaction: {
      mode: 'index',
      intersect: true,
    },
    stacked: true,
    responsive: true,
    plugins: {
      title: {
        display: true,
        text: 'Chart.js Line Chart - Cubic interpolation mode'
      },
    },
    interaction: {
      intersect: false,
    },
    scales: {
      x: {
        grid: {
          display: false
        },
        display: true,
        title: {
          display: true
        }
      },
      y: {
        grid: {
          display: false
        },
        display: true,
        title: {
          display: true,
          text: 'Value'
        },
        suggestedMin: -10,
        suggestedMax: 200
      }
    }
  };
  var bubbleData = {
    datasets: [
      {
        label: 'John',
        data: [
          {
            x: 3,
            y: 7,
            r: 10
          }
        ],
        backgroundColor: "#800000",
        hoverBackgroundColor: "#F08080",
        hoverRadius: 4, // reduce radius on hover
        pointStyle: 'rectRounded',
        borderWidth: 2,
        borderColor: '#08516A',
        hoverBorderWidth: 5,
      },
      {
        label: 'Paul',
        data: [
          {
            x: 6,
            y: 2,
            r: 10
          }
        ],
        backgroundColor: "#00FFFF",
        hoverBackgroundColor: "#AFEEEE",
        hoverRadius: 4, // reduce radius on hover
        borderWidth: 2,
        borderColor: '#1FDA35',
        hoverBorderWidth: 5,
      },
      {
        label: 'George',
        data: [
          {
            x: 2,
            y: 6,
            r: 10
          }
        ],
        backgroundColor: "#FF6347",
        hoverBackgroundColor: "#FA8072",
        hoverRadius: 4, // reduce radius on hover
        borderWidth: 2,
        borderColor: '#1FDA35',
        hoverBorderWidth: 5,
      },
      {
        label: 'Ringo',
        data: [
          {
            x: 5,
            y: 3,
            r: 10
          }
        ],
        backgroundColor: "#FFA500",
        hoverBackgroundColor: "#EEE8AA",
        hoverRadius: -4, // reduce radius on hover
      },
      {
        label: 'John',
        data: [
          {
            x: 2,
            y: 1,
            r: 10
          }
        ],
        backgroundColor: "#228B22",
        hoverBackgroundColor: "#90EE90",
        hoverRadius: -4, // reduce radius on hover
      },
      {
        label: 'George',
        data: [
          {
            x: 1,
            y: 3,
            r: 10
          }
        ],
        backgroundColor: "#00008B",
        hoverBackgroundColor: "#87CEFA",
        hoverRadius: -4, // reduce radius on hover
      },
      {
        label: 'Ringo',
        data: [
          {
            x: 1,
            y: 1,
            r: 10
          }
        ],
        backgroundColor: "#800080",
        hoverBackgroundColor: "#DDA0DD",
        hoverRadius: -4, // reduce radius on hover
      },
      {
        label: 'George',
        data: [
          {
            x: 1,
            y: 2,
            r: 10
          }
        ],
        backgroundColor: "#8B4513",
        hoverBackgroundColor: "#D2B48C",
        hoverRadius: -4, // reduce radius on hover
      }
    ]
  };
  var bubbleOptions = {
    plugins: {
      subtitle: {
        display: false,
        text: 'Custom Chart Subtitle'
      },
      title: {
        text: 'Title for this chart',
        display: true,
        position: 'left',
      },
      legend: {
        position: 'bottom',//Position of the legend. ('top','left','right','chartArea')
        align: 'center',  //Alignment of the legend.options :'start','center'
        maxHeight: 25,
      }

    },
    scales: {
      x: {
        display: true,        // show/ hide x-axis(default : true)
        grid: {
          display: false,      // show/hide grid line in x-axis(default : true)
        },
      },
      y: {
        display: true,      // same as x-axis
        grid: {
          display: false
        }
      }
    },
  }
  var pieData = {
    labels: ['OK', 'WARNING', 'CRITICAL', 'UNKNOWN'],
    datasets: [{
      label: '# of Tomatoes',
      data: [12, 19, 3, 5],
      borderWidth: 50,
      hoverOffset: 50,
      rotation: 50, //Starting angle to draw arcs from.
      weight: 90,
      hoverBorderWidth: 5,
      borderJoinStyle: 'bevel', //arc border join style (round,miter-default)
      backgroundColor: [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)'
      ],
      borderColor: [
        'rgba(255,99,132,1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)'
      ],
      borderWidth: 1
    }]
  };
  var donutData = {
    labels: ['OK', 'WARNING', 'CRITICAL', 'UNKNOWN'],
    datasets: [{
      label: '# of Tomatoes',
      data: [12, 19, 3, 5],
      borderWidth: 50,
      hoverOffset: 50,
      spacing: 10,
      cutout: 40, //The portion of the chart that is cut out of the middle. 
      rotation: 50, //Starting angle to draw arcs from.
      weight: 90,
      // clip: {left: 5, top: false, right: -2, bottom: 0},
      hoverBorderWidth: 5,
      borderJoinStyle: 'bevel', //arc border join style (round,miter-default)
      backgroundColor: [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)'
      ],
      borderColor: [
        'rgba(255,99,132,1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)'
      ],
      borderWidth: 1
    }]
  };
  var donutOptions = {
    animation: {
      animateScale: true,
      duration: 5000,
    },
    interaction: {
      intersect: true,
      axis: 'r',  //define which directions are used in calculating distances.
    },
    layout: {
      padding: 30,  // padding to add inside the chart
    },
    responsive: true,
  };
  var pieOptions = {
    interaction: {
      intersect: false,
      axis: 'r',
    },
    layout: {
      padding: 10,  // padding to add inside the chart
    },
    elements: {
      arc: {
        borderJoinStyle: 'miter',
      },
    },
    //cutoutPercentage: 40,
    responsive: false,
};
  var comboData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [{
      label: "Dataset1",
      type: 'line',
      backgroundColor: "#0000FF",
      borderColor: "#E915C8",
      borderWidth: 1,
      fill: false,
      hoverBorderWidth: 35,
      pointHoverBorderColor: '#0000FF',
      data: [12296, 12381, 9141, 24203, 21987, 21801, 65394, 91892, 57645, 44637, 22631, 17502]
    }, {
      label: "Dataset2",
      backgroundColor: "rgb(255, 195, 0)",
      borderColor: "rgb(238, 124, 54 )",
      hoverBackgroundColor: 'rgb(255, 195, 0, 0.3)',
      borderWidth: 3,
      fill: true,
      data: [299405, 244029, 247191, 329711, 273855, 441914, 426271, 471912, 374388, 366864, 326155, 277442]
    }]
  };
  let delayed;
  var comboOPtions = {
    animation: {
      onComplete: () => {
        delayed = true;
      },
      delay: (context) => {
        let delay = 0;
        if (context.type === 'data' && context.mode === 'default' && !delayed) {
          delay = context.dataIndex * 300 + context.datasetIndex * 100;
        }
        return delay;
      },
    },
    elements: {
      point: {
        pointStyle: 'crossRot',
        radius: 10,

      },
    },
    scales: {
      y: {
        stacked: true,
}
    },
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Chart.js Combined Line/Bar Chart'
      }
    }
  };
  var multiSeriesData = {
    labels: ['Overall Yay', 'Overall Nay', 'Group A Yay', 'Group A Nay', 'Group B Yay', 'Group B Nay', 'Group C Yay', 'Group C Nay'],
    datasets: [
      {
        backgroundColor: ['#AAA', '#777'],
        data: [21, 79]
      },
      {
        backgroundColor: ['hsl(0, 100%, 60%)', 'hsl(0, 100%, 35%)'],
        data: [33, 67]
      },
      {
        backgroundColor: ['hsl(100, 100%, 60%)', 'hsl(100, 100%, 35%)'],
        data: [20, 80]
      },
      {
        backgroundColor: ['hsl(180, 100%, 60%)', 'hsl(180, 100%, 35%)'],
        data: [10, 90]
      }
    ]
  };
var polarData = {
    labels: [
      'Red',
      'Green',
      'Yellow',
      'Grey',
      'Blue'
    ],
    datasets: [{
      label: 'My First Dataset',
      data: [11, 16, 7, 3, 14],
      // clip: 100,
      hoverBackgroundColor: [
        'rgb(255, 99, 132,0.7)',
        'rgb(75, 192, 192,0.7)',
        'rgb(255, 205, 86,0.7)',
        'rgb(201, 203, 207,0.7)',
        'rgb(54, 162, 235,0.7)'
      ],
      borderAlign: 'inner', //  	'center' would collide the borders
      borderJoinStyle: 'miter',
      borderColor: ['rgb(255, 99, 132)',
        'rgb(75, 192, 192)',
        'rgb(255, 205, 86)',
        'rgb(201, 203, 207)',
        'rgb(54, 162, 235)'],
      backgroundColor: [
        'rgb(255, 99, 132,0.4)',
        'rgb(75, 192, 192,0.4)',
        'rgb(255, 205, 86,0.4)',
        'rgb(201, 203, 207,0.4)',
        'rgb(54, 162, 235,0.4)'
      ]
    }]
  };
  var polarOptions = {
    scales: {
      r: {
        pointLabels: {
          display: true,
          centerPointLabels: true,
          font: {
            size: 18
          }
        }
      }
    },
    animation: {
      animateRotate: true, //rotation effect
    }
  }
  var radarData = {
    labels: [
      'Eating',
      'Drinking',
      'Sleeping',
      'Designing',
      'Coding',
      'Cycling',
      'Running'
    ],
    datasets: [{
      label: 'My First Dataset',
      data: [65, 59, 90, 81, 56, 55, 40],
      backgroundColor: 'rgba(255, 99, 132, 0.2)',
      borderColor: 'rgb(255, 99, 132)',
      pointBackgroundColor: 'rgb(255, 99, 132)',
      pointBorderColor: '#E915C8',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgb(255, 99, 132)',
      borderJoinStyle: 'miter',
      borderWidth: 5,
      hoverBorderDashOffset: 5,
      hoverBorderWidth: 10,
      borderDash: [3, 4, 8],
      borderDashOffset: 10,
      order: 6,//The drawing order of dataset. Also affects order for tooltip and legend.
      tension: 1,
      pointHitRadius: 100,
    },
    {
      label: 'My Second Dataset',
      data: [28, 48, 40, 19, 96, 27, 100],
      fill: true,
      borderWidth: 1,
      backgroundColor: 'rgba(54, 162, 235, 0.2)',
      borderColor: 'rgb(54, 162, 235)',
      pointBackgroundColor: 'rgb(54, 162, 235)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgb(54, 162, 235)'
    }]
  };
  var radarOptions = {
    elements: {
      line: {
        spanGaps: false, //If true, lines will be drawn between points with no or null data. If false, points with null data will create a break in the line.
        clip: { left: 5, top: false, right: -2, bottom: 0 },
        borderWidth: 3,
        hoverBackgroundColor: 'rgb(255, 99, 132, 0.9)',
      }
    },
  };
  var scatterData = {
    datasets: [{
      label: 'Dataset 1',
      data: [{
        x: -10,
        y: 0
      }, {
        x: 0,
        y: 10
      }, {
        x: 10,
        y: 5
      }, {
        x: 0.5,
        y: 5.5
      },
      {
        x: 5,
        y: 4
      }, {
        x: 2,
        y: 14
      },
      {
        x: 4,
        y: 12
      },
      {
        x: 2,
        y: 10
      },
      {
        x: 3,
        y: 4
      },
      {
        x: 3,
        y: 5
      },
      {
        x: 3,
        y: 8
      },
      {
        x: 6,
        y: 12

      }],
backgroundColor: 'rgb(108, 185, 20)'
    },
    {
      label: 'Dataset 2',
      data: [{
        x: -13,
        y: 3
      }, {
        x: -4,
        y: 11
      }, {
        x: 15,
        y: -5
      }, {
        x: 3.5,
        y: 1.5
      },
      {
        x: 5,
        y: -4
      }, {
        x: -5,
        y: -4
      }, {
        x: 6,
        y: 11
      },
      {
        x: -2,
        y: 10
      },
      {
        x: -7,
        y: 11
      },
      {
        x: 5,
        y: 2
      },
      {
        x: 3,
        y: 5
      },
      {
        x: 3,
        y: -3
      },
      {
        x: -6,
        y: 2

      }],

      backgroundColor: 'rgb(222, 48, 230)'
    }
    ],
  };
  var qScatterOptions = {
    elements: {
      point: {
        radius: 7,
        hoverRadius: 12,
        hoverBackgroundColor: '#E63062',
      },
    },
    plugins: {
      quadrants: {
        topLeft: 'rgb(244, 240, 107 ,0.2)',
        topRight: 'rgb(123, 244, 107 ,0.2)',
        bottomRight: 'rgb(107, 244, 220 ,0.2)',
        bottomLeft: 'rgb(244, 126, 107 ,0.2)',
      }
    }
  };
  var scatterOptions = {
    plugins: {
      chartAreaBorder: {
        borderColor: '#010100',
        borderWidth: 2,
        borderDash: [5, 5],
        borderDashOffset: 2,
      }
    },
    elements: {
      point: {
        radius: 7,
        pointStyle: 'triangle',
        hoverRadius: 15,
        hoverBackgroundColor: '#E63062',
      },
    },
    scales: {
      x: {
        display: true,
        type: 'linear',
        position: 'bottom',
        grid: {
          color: function (context) {
            if (context.tick.value > 0) {
              return '#A9F45D';
            } else if (context.tick.value < 0) {
              return '#F4715D';
            }

            return '#E2E1E1';
          },
        },
      },

      y: {
        grid: {
          color: function (context) {
            if (context.tick.value > 0) {
              return '#A9F45D';
            } else if (context.tick.value < 0) {
              return '#F4715D';
            }

            return '#E2E1E1';
          },
        },
      },
    }

  };
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/" element={<Barchart data={barData} options={barOptions} />} />
        <Route exact path="/sbar" element={<StackedBarChart data={sBarData} options={sBarOptions} />} />
        <Route exact path="/line" element={<LineChart data={lineData} options={lineOptions} />} />
        <Route exact path="/mline" element={<MultiLineChart data={mLineData} options={mLineOptions} />} />
        <Route exact path="/sline" element={<SteppedLineChart data={sLineData} options={sLineOptions} />} />
        <Route exact path="/area" element={<AreaChart data={areaData} options={areaOptions} />} />
        <Route exact path="/bubble" element={<BubbleChart data={bubbleData} options={bubbleOptions} />} />
        <Route exact path="/doughnut" element={<DoughnutChart data={donutData} options={donutOptions} />} />
        <Route exact path="/pie" element={<PieChart data={pieData} options={pieOptions} />} />
        <Route exact path="/combo" element={<BarLineChart data={comboData} options={comboOPtions} />} />
        <Route exact path="/multi" element={<MultiSeriesPieChart data={multiSeriesData} />} />
        <Route exact path="/polar" element={<PolarAreaChart data={polarData} options={polarOptions} />} />
        <Route exact path="/radar" element={<RadarChart data={radarData} options={radarOptions} />} />
        <Route exact path="/scatter" element={<ScatterChart data={scatterData} options={scatterOptions} />} />
        <Route exact path="/qscatter" element={<QScatterChart data={scatterData} options={qScatterOptions} />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
